import 'package:flutter/material.dart';

get advertisingTab => const Center(child: Text("Anúncio"));