import 'package:flutter/material.dart';

get menuTab => const Center(child: Text("Menu"));