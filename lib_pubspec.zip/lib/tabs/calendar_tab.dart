import 'package:flutter/material.dart';

get calendarTab => const Center(child: Text("Calendário"));