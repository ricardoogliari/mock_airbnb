import 'package:flutter/material.dart';

get messagesTab => const Center(child: Text("Mensagens"));